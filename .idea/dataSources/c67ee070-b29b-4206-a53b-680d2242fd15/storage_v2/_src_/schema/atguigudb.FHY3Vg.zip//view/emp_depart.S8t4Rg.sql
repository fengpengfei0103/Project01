CREATE VIEW emp_depart AS
  SELECT concat(`e`.`last_name`, '(', `d`.`department_name`, ')') AS `emp_dept`
  FROM (`atguigudb`.`employees` `e`
    JOIN `atguigudb`.`departments` `d`)
  WHERE (`e`.`department_id` = `d`.`department_id`);

