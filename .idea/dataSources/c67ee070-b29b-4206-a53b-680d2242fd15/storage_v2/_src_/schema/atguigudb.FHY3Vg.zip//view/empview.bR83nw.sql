CREATE VIEW empview AS
  SELECT
    `e`.`employee_id`     AS `emp_id`,
    `e`.`last_name`       AS `NAME`,
    `d`.`department_name` AS `department_name`
  FROM `atguigudb`.`employees` `e`
    JOIN `atguigudb`.`departments` `d`
  WHERE (`e`.`department_id` = `d`.`department_id`);

