CREATE VIEW emp08 AS
  SELECT
    `atguigudb`.`employees`.`employee_id` AS `employee_id`,
    `atguigudb`.`employees`.`last_name`   AS `last_name`,
    `atguigudb`.`employees`.`salary`      AS `salary`
  FROM `atguigudb`.`employees`
  WHERE (`atguigudb`.`employees`.`department_id` = 80);

