CREATE VIEW employee_vu AS
  SELECT
    `atguigudb`.`employees`.`last_name`     AS `last_name`,
    `atguigudb`.`employees`.`employee_id`   AS `employee_id`,
    `atguigudb`.`employees`.`department_id` AS `department_id`
  FROM `atguigudb`.`employees`
  WHERE (`atguigudb`.`employees`.`department_id` = 80);

